onEvent("rightbutton", "click", function(){
setScreen("rightscreen");
});
onEvent("continueburga", "click", function( ) {
  setScreen("burgerscreen");
});
onEvent("lastpage", "click", function( ) {
  setScreen("lastpage2");
});
